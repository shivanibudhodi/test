declare const WP_ADMIN_USER: {
    readonly username: "automation";
    readonly password: "automation";
};
declare const WP_USERNAME: string, WP_PASSWORD: string, WP_BASE_URL: string;
export { WP_ADMIN_USER, WP_USERNAME, WP_PASSWORD, WP_BASE_URL };
//# sourceMappingURL=config.d.ts.map