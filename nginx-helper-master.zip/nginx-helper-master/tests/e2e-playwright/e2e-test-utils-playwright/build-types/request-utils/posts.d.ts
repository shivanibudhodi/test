/**
 * Delete all posts using REST API.
 *
 * @this {import('./index').RequestUtils}
 */
export function deleteAllPosts(): Promise<void>;
//# sourceMappingURL=posts.d.ts.map