/**
 * Internal dependencies
 */
import type { RequestUtils } from './index';
declare function activateTheme(this: RequestUtils, themeSlug: string): Promise<void>;
export { activateTheme };
//# sourceMappingURL=themes.d.ts.map